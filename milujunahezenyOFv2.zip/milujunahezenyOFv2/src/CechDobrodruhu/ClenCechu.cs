﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CechDobrodruhu
{
    internal class ClenCechu
    {
        public string jmeno;


    }
}
