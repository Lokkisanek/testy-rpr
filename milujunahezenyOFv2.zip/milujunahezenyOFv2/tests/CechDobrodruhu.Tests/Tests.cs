using System;

namespace CechDobrodruhu.RucniTesty;

class Program
{
    static void Main()
    {

        Console.WriteLine("\nTESTY: cech");
        Test_Clen_ZakladniStaty();
        Test_Clen_TreningPridaStavu();
        Test_Clen_DostavaniDMG();

        Console.WriteLine("\nTESTY: dobrodruh");
        Test_Dobrodruh_VytvoreniAZmenaPovolani();
        Test_Dobrodruh_ZkusenostiALevelovani();
        Test_Dobrodruh_SchopnostiAEnergie();

        Console.WriteLine("\nTESTY: obchod");
        Test_Obchodnik_VytvoreniAStavKramu();
        Test_Obchodnik_ProdejADoplnovani();
        Test_Obchodnik_Odpocinek();

        Console.WriteLine("testy dojely");
        Console.ReadLine();
    }

    // TESTY: cech

    static void Test_Clen_ZakladniStaty()
    {
        var clen = new ClenCechu("Aron");
        if (clen.Jmeno == "Aron" && clen.Zdravi == 100 && clen.Energie == 50 && clen.JeAktivni)
            Console.WriteLine("OK: Clen_ZakladniStaty");
        else
            Console.WriteLine("CHYBA: Borec po vytvo�en� nem� spr�vn� staty!");
    }

    static void Test_Clen_TreningPridaStavu()
    {
        var clen = new ClenCechu("Aron");
        clen.Trenuj(20);
        if (clen.Energie == 70)
            Console.WriteLine("OK: Clen_TreningPridaStavu");
        else
            Console.WriteLine($"CHYBA: Tr�nink nefunguje! O�ek�v�no 70 energie, ale borec m� {clen.Energie}.");
    }

    static void Test_Clen_DostavaniDMG()
    {
        var clen = new ClenCechu("Aron");
        clen.UtrzZraneni(150);
        if (clen.Zdravi == 0 && clen.JeAktivni == false)
            Console.WriteLine("OK: Clen_KdyzDostanuMocDMG_TakJsemMimo");
        else
            Console.WriteLine("CHYBA: Borec dostal 150 dmg, ale po��d stoj� na nohou!");
    }

    // TESTY: dobrodruh

    static void Test_Dobrodruh_VytvoreniAZmenaPovolani()
    {
        var d = new Dobrodruh("Eryn", "M�g", Zbran.Hul, Brneni.Latkove);
        var spatnyJob = new Dobrodruh("Eryn", "Alchymista", Zbran.Mec, Brneni.Kozene);

        d.Povolani = "Kov��"; 

        if (d.Jmeno == "Eryn" && d.Povolani == "M�g" && spatnyJob.Povolani == null)
            Console.WriteLine("OK: Dobrodruh_VytvoreniAZmenaPovolani");
        else
            Console.WriteLine("CHYBA: Dobrodruh se blb� vytv��� nebo mu nefunguj� povol�n�!");
    }

    static void Test_Dobrodruh_ZkusenostiALevelovani()
    {
        var d = new Dobrodruh("Eryn", "M�g", Zbran.Hul, Brneni.Latkove);

        d.PridejZkusenosti(250); 
        d.PridejZkusenosti(-50); 

        if (d.Zkusenosti == 250 && d.Uroven == 3)
            Console.WriteLine("OK: Dobrodruh_ZkusenostiALevelovani");
        else
            Console.WriteLine("CHYBA: Dobrodruh m� �patn� XP nebo Level!");
    }

    static void Test_Dobrodruh_SchopnostiAEnergie()
    {
        var d = new Dobrodruh("Eryn", "M�g", Zbran.Hul, Brneni.Latkove);

        bool funguje = d.PouzijSchopnost(); 

   
        while (d.Energie > 9) d.PouzijSchopnost();

        bool bezEnergie = d.PouzijSchopnost(); 

        if (funguje && !bezEnergie && d.Energie == 0)
            Console.WriteLine("OK: Dobrodruh_SchopnostiAEnergie");
        else
            Console.WriteLine("CHYBA: Dobrodruh m��e kouzlit bez energie nebo mu to neub�r�!");

    // TESTY: obchodnik

    static void Test_Obchodnik_VytvoreniAStavKramu()
    {
        var o1 = new Obchodnik("Borin", TypObchodu.Zbrane, true);
        var o2 = new Obchodnik("Gimli", TypObchodu.Lektvary);

        if (o1.MaSlevu && !o2.MaSlevu && o1.PocetPredmetu == 10)
                Console.WriteLine("OK: Obchodnik_VytvoreniAStavKramu");
        else
                Console.WriteLine("CHYBA: Obchodn�k se vytv��� se �patn�mi startovn�mi hodnotami!");
    }

    static void Test_Obchodnik_ProdejADoplnovani()
    {
        var o = new Obchodnik("Borin", TypObchodu.Zbrane);

        o.Prodej(3); 
        o.Prodej(100); 
        o.DoplnZbozi(5); 
        o.DoplnZbozi(-10); 

        if (o.PocetPredmetu == 5)
                Console.WriteLine("OK: Obchodnik_ProdejADoplnovani");
        else
                Console.WriteLine($"CHYBA: Obchodn�kovi nesed� sklad! M� {o.PocetPredmetu} v�c�.");
    }

    static void Test_Obchodnik_Odpocinek()
    {
        var o = new Obchodnik("Borin", TypObchodu.Zbrane);

        o.UtrzZraneni(20);
        o.Odpocivej(); 

        if (o.Zdravi == 85 && o.Energie == 50)
                Console.WriteLine("OK: Obchodnik_Odpocinek");
        else
                Console.WriteLine("CHYBA: Obchodn�k odpo��v� jinak ne� by m�l!");
    }



}